
import { PrismaClient } from '@/generated/client'
import { PrismaPg } from '@prisma/adapter-pg'

const globalForPrisma = global as unknown as {
    prisma?: PrismaClient
}

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL,
})

const cachedPrisma = globalForPrisma.prisma;
const hasCurrentFinanceDelegates =
  cachedPrisma &&
  "financialCategory" in cachedPrisma &&
  "plannedExpense" in cachedPrisma &&
  "savingsContribution" in cachedPrisma &&
  "studyPlanProgress" in cachedPrisma;

const prisma: PrismaClient = hasCurrentFinanceDelegates ? cachedPrisma : new PrismaClient({
  adapter,
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma

export default prisma
