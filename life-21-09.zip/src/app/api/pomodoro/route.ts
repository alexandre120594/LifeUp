import prisma from "@/lib/prisma";
import { requireCurrentUserId } from "@/lib/auth";
import { buildPomodoroDashboard } from "@/lib/pomodoro";
import { NextRequest, NextResponse } from "next/server";

function normalizeSession(session: {
  durationMinutes: number;
  endedAt: Date;
  focusType: string;
  id: string;
  notes: string | null;
  startedAt: Date;
  title: string | null;
  subject: {
    color: string | null;
    id: string;
    name: string;
  } | null;
  subjectId: string | null;
}) {
  return {
    durationMinutes: session.durationMinutes,
    endedAt: session.endedAt,
    focusType: "study" as const,
    id: session.id,
    notes: session.notes,
    startedAt: session.startedAt,
    title: session.title,
    subject: session.subject,
    subjectId: session.subjectId,
  };
}

export async function GET() {
  const { response, userId } = await requireCurrentUserId();

  if (response) {
    return response;
  }

  const sessions = await prisma.pomodoroSession.findMany({
    where: { userId },
    include: {
      subject: true,
    },
    orderBy: { endedAt: "desc" },
  });

  return NextResponse.json(
    buildPomodoroDashboard(sessions.map(normalizeSession))
  );
}

export async function POST(req: NextRequest) {
  const { response, userId } = await requireCurrentUserId();

  if (response) {
    return response;
  }

  try {
    const { durationMinutes, endedAt, notes, startedAt, subjectId, title } =
      await req.json();
    const parsedDuration = Number(durationMinutes);
    const parsedStartedAt = new Date(startedAt);
    const parsedEndedAt = new Date(endedAt);
    const parsedSubjectId = typeof subjectId === "string" ? subjectId.trim() : "";
    const parsedTitle = typeof title === "string" ? title.trim() : "";

    if (
      !Number.isInteger(parsedDuration) ||
      parsedDuration <= 0 ||
      parsedDuration > 24 * 60 ||
      !parsedTitle ||
      parsedTitle.length > 120 ||
      !parsedSubjectId ||
      Number.isNaN(parsedStartedAt.getTime()) ||
      Number.isNaN(parsedEndedAt.getTime()) ||
      parsedEndedAt < parsedStartedAt
    ) {
      return NextResponse.json(
        { error: "Valid session name, subject, duration, start, and end times are required." },
        { status: 400 }
      );
    }

    const subject = await prisma.studySubject.findFirst({
      where: { id: parsedSubjectId, userId },
      select: { id: true },
    });

    if (!subject) {
      return NextResponse.json(
        { error: "Study subject not found." },
        { status: 404 }
      );
    }

    const session = await prisma.pomodoroSession.create({
      data: {
        durationMinutes: parsedDuration,
        endedAt: parsedEndedAt,
        focusType: "study",
        notes: typeof notes === "string" && notes.trim() ? notes.trim() : null,
        startedAt: parsedStartedAt,
        subjectId: parsedSubjectId,
        title: parsedTitle,
        userId,
      },
      include: {
        subject: true,
      },
    });

    return NextResponse.json(normalizeSession(session), { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: "Unable to save pomodoro session.", detail: error },
      { status: 500 }
    );
  }
}
